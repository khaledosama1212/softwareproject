require('dotenv').config();
const username = encodeURIComponent(process.env.USER);
const password = encodeURIComponent(process.env.PASS);
const clusterUrl = process.env.DB_CLUSTER_URL;
const url = `mongodb+srv://${username}:${password}@${clusterUrl}/`;

const jwt = require('jsonwebtoken');
const express = require("express")
const port = process.env.PORT || 3001;
const { MongoClient } = require('mongodb');


// Create a new MongoClient instance with the URL
const client = new MongoClient(url);
const app = express();

// Middleware function to log incoming requests
app.use((req, res, next) => {
    console.log('The middleware received the request:', req.method, req.url);
    next();
});

app.use(express.json());



function authenticateToken(req, res, next) {
    const token = extractToken(req.headers.authorization);
    if (!token) {
        return res.status(401).send('Token not provided');
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).send('Token is invalid or expired');
        }
        req.user = user;
        next();
    });
}

function extractToken(authorizationHeader) {
    if (!authorizationHeader || !authorizationHeader.startsWith('Bearer ')) {
        return null;
    }
    return authorizationHeader.split(' ')[1];
}

module.exports = authenticateToken;





client.connect()
    .then(() => {
        console.log('Connected to MongoDB');
        const dba = client.db('porsche'); // Get the database instance


        app.post('/register', async (req, res) => {
            const { email, password, username, gender} = req.body;

            try {
                // Check if the username already exists
                const existingUser = await dba.collection('customers').findOne({ username: username });
                if (existingUser) {
                    return res.status(409).send(' please log in you are already registered.');  // 409 Conflict might be appropriate here
                }
                // Insert the new user with the provided plain password (not recommended for production)
                await dba.collection('customers').insertOne({
                    email,
                    password,
                    username,
                    gender,
                    

            
                });

                res.status(201).send('User registered successfully');
            } catch (err) {
                console.error('Failed to register user:', err);
                res.status(500).send('Internal server error');
            }
        });




        app.get('/products', async (req, res) => {
            try {
                const products = await dba.collection('products').find().toArray();
                res.status(200).json(products);
            } catch (error) {
                console.error('Error fetching products:', error);
                res.status(500).json({ error: "Could not get the products" });
            }
        });
        

        // Define a function to fetch products from the database
async function fetchProducts(req, res) {
    const products = await dba.collection('products').find().toArray();
    res.status(200).json(products);
}

// Define a function to handle errors when fetching products
function handleFetchError(err, res) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: "Could not get the products" });
}

// Endpoint to fetch products
app.get('/products', async (req, res) => {
    try {
        await fetchProducts(req, res);
    } catch (error) {
        handleFetchError(error, res);
    }
});


  // Endpoint to handle user login
  app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        // Try to find the user in the Admins collection first
        let user = await  dba.collection('Admins').findOne({ username });
        let isAdmin = false;  // Flag to check if the user is an admin

        if (user) {
            isAdmin = true;  // User found in Admins, set as admin
        } else {
            // If not found in Admins, check in Customers
            user = await dba.collection('customers').findOne({ username });
            if (!user) {
                console.log("No user found in Admins or Customers collections.");
                return res.status(401).send('User not found.');
            }
        }

        // Check password correctness
        if (user.password !== password) {
            return res.status(401).send('Invalid credentials.');
        }

        // Issue token and response based on user type
        if (isAdmin) {
            const token = jwt.sign(
                { userId: user._id, username: user.username, isAdmin: true },
                process.env.JWT_SECRET || 'nigger',

            );

            res.json({ message: 'Login Successfully', token: token });
        } else {
            // For non-admins, simply authenticate without a token
            res.status(200).send('Login Successfully');
        }
    } catch (error) {
        console.error("Database query failed:", error);
        return res.status(500).json({ error: error.toString() });
    }
});




        //add products
       // Function to add or update a product
async function addOrUpdateProduct(req, res) {
    const { model, color, year, quantity, price } = req.body;

    // Define a query to check if the product already exists
    const query = { model, color, year };

    try {
        // Attempt to find an existing product that matches the query
        const existingProduct = await dba.collection('products').findOne(query);

        if (existingProduct) {
            // Increment the stock quantity by one and convert it back to a string
            const newquantity = (parseInt(existingProduct.quantity, 10) + quantity).toString();

            // Update the product with the new stock quantity as a string
            await dba.collection('Products').updateOne(
                { _id: existingproduct._id },
                { $set: { quantity: newquantity } }
            );
            res.status(200).send('Product quantity was increased successfully');
        } else {
            // Create a new product entry
            const newProduct = {
                model,
                color,
                year,
                quantity,
                price
            };
            await dba.collection('products').insertOne(newproduct);
            res.status(201).send('New product added successfully');
        }
    } catch (error) {
        console.error('Error in managing product:', error);
        res.status(500).json({ error: error.message });
    }
}

// Endpoint to add or update a product
app.post('/admin/productsAdd', authenticateToken, async (req, res) => {
    try {
        // Check if the user is an admin
        if (!req.user.isAdmin) {
            return res.status(403).send('Access denied: Requires moderator authorization');
        }
        await addOrUpdateProduct(req, res);
    } catch (error) {
        console.error('Error in /admin/productsAdd:', error);
        res.status(500).json({ error: error.message });
    }
});






//update product
        app.put('/admin/productsUpdate', authenticateToken, async (req, res) => {
            const { Model, Year } = req.body;  // Get matching criteria from request body
            const productUpdates = req.body.updates;  // Get update fields from request body

            try {
                // Check if the user is an admin
                if (!req.user.isAdmin) {
                    return res.status(403).send('Access denied. Only admins can edit products.');
                }

                // Define the filter for the product to update
                const filter = { Year, Model };

                // Perform the update operation
                const updatedProduct = await dba.collection('Products').updateOne(
                    filter,
                    { $set: productUpdates }
                );

                // Check if any document was actually updated
                if (updatedProduct.matchedCount === 0) {
                    return res.status(404).send('Product not found.');
                }

                res.json({ message: 'Product updated successfully.' });
            } catch (err) {
                console.error('Error updating product:', err);
                res.status(500).send('Internal server error');
            }
        });

        //delete product
        app.delete('/admin/productsDelete', authenticateToken, async (req, res) => {
            const { Year, Model } = req.body;

            try {
                if (!req.user.isAdmin) {
                    return res.status(403).send('Access denied: Requires admin privileges');
                }

                // Build the query object for deletion
                const query = { Year, Model };

                // Perform the deletion operation
                const result = await dba.collection('products').deleteOne(query);

                // Check the result of the deletion
                if (result.deletedCount === 0) {
                    return res.status(404).send('Product not found.');
                }

                // If deletion was successful and some documents were deleted
                res.status(200).send('Product Deleted Successfully.');
            } catch (error) {
                console.error('Error during product deletion:', error);
                res.status(500).json({ error: error.message });
            }
        });

        //order
        app.post('/admin/productsOrder', authenticateToken, async (req, res) => {
            const { year, model } = req.body; // Data to identify the product

            try {
                // Check if the user is an admin
                if (!req.user.isAdmin) {
                    return res.status(403).send('Access denied. Only admins can make orders.');
                }

                // Find the product and check the stock
                const product = await dba.collection('products').findOne({ year, model });

                if (!product) {
                    return res.status(404).send('Product not found.');
                }

                if (product.StockQuantity <= 0) {
                    return res.status(400).send('Product is out of stock.');
                }

                // Decrement the stock quantity by one
                const updatedquantity = parseInt(product.quantity, 10) - 1;

                // Update the product in the database
                await dba.collection('products').updateOne(
                    { _id: product._id },
                    { $set: { StockQuantity: updatedQuantity.toString() } } // Convert back to string if necessary
                );

                res.status(200).send('Order made successfully, stock quantity updated.');
            } catch (error) {
                console.error('Error making order:', error);
                res.status(500).send('Internal server error');
            }
        });






        app.get('/protected-route', authenticateToken, (req, res) => {
            res.send('This is a protected route');
        });















        app. listen(port, ()=> {
            console.log("Server is running: listening to port " + port)
        })
    })
    .catch(error => {
        console.error('Error connecting to MongoDB:', error);
    });